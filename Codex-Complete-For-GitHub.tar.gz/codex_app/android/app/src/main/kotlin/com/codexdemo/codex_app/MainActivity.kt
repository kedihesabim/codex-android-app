package com.codexdemo.codex_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
