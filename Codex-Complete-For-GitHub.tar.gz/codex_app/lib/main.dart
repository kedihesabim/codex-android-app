import 'package:flutter/material.dart';

void main() {
  runApp(const CodexApp());
}

class CodexApp extends StatelessWidget {
  const CodexApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Codex',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue, brightness: Brightness.dark),
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      themeMode: ThemeMode.system,
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final projects = ['openai', 'superassistant', 'codex', 'android-app', 'todo-demo'];
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.menu), onPressed: () {}),
        title: const Text('Codex', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(icon: const Icon(Icons.more_horiz), onPressed: () {}),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                _Chip('All', selected: true),
                const SizedBox(width: 8),
                _Chip('Laptop', hasDot: true),
                const SizedBox(width: 8),
                _Chip('Desktop', hasDot: true),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text('Projeler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: projects.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: const Icon(Icons.folder_outlined),
                  title: Text(projects[index]),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => ChatScreen(project: projects[index])),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Ara...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                ),
              ),
            ),
            const SizedBox(width: 8),
            FloatingActionButton.extended(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen(project: 'Yeni')));
              },
              label: const Text('Sohbet'),
              icon: const Icon(Icons.chat),
            ),
          ],
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final bool selected;
  final bool hasDot;
  const _Chip(this.label, {this.selected = false, this.hasDot = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: selected ? Colors.black : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (hasDot) ...[
            Container(width: 8, height: 8, decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle)),
            const SizedBox(width: 4),
          ],
          Text(label, style: TextStyle(color: selected ? Colors.white : Colors.black)),
        ],
      ),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final String project;
  const ChatScreen({super.key, required this.project});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final List<Map<String, String>> messages = [
    {'role': 'user', 'text': 'React Native ile basit bir todo uygulaması yaz'},
    {'role': 'ai', 'text': 'Tabii! İşte basit bir Todo uygulaması:\n\n```dart\nclass TodoApp extends StatefulWidget {\n  @override\n  _TodoAppState createState() => _TodoAppState();\n}\n\nclass _TodoAppState extends State<TodoApp> {\n  List<String> todos = [];\n  // ... kod devam ediyor\n}\n```'},
  ];
  final TextEditingController _controller = TextEditingController();

  void _send() {
    if (_controller.text.isEmpty) return;
    setState(() {
      messages.add({'role': 'user', 'text': _controller.text});
      messages.add({'role': 'ai', 'text': 'Görev alındı. İşleniyor...\n\nKod üretildi ve dosyalar güncellendi.'});
      _controller.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.project),
        actions: [
          IconButton(
            icon: const Icon(Icons.terminal),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TaskScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.difference),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DiffScreen())),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: messages.length,
              itemBuilder: (context, i) {
                final msg = messages[i];
                final isUser = msg['role'] == 'user';
                return Align(
                  alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isUser ? Colors.blue.shade100 : Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                    child: Text(msg['text'] ?? ''),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: 'Mesaj yaz...',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                IconButton(icon: const Icon(Icons.mic), onPressed: () {}),
                IconButton(icon: const Icon(Icons.send), onPressed: _send),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TaskScreen extends StatelessWidget {
  const TaskScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Aktif Görev')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Kullanıcı kimlik doğrulama sistemi', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            const Text('İlerleme: 4/7 adım'),
            const LinearProgressIndicator(value: 4/7, minHeight: 8),
            const SizedBox(height: 24),
            const Text('Değişen dosyalar:', style: TextStyle(fontWeight: FontWeight.w600)),
            const ListTile(leading: Icon(Icons.insert_drive_file), title: Text('auth.service.ts')),
            const ListTile(leading: Icon(Icons.insert_drive_file), title: Text('auth.controller.ts')),
            const SizedBox(height: 16),
            const Text('Terminal:', style: TextStyle(fontWeight: FontWeight.w600)),
            Container(
              padding: const EdgeInsets.all(12),
              color: Colors.black,
              child: const Text(
                '\$ npm test\nAll tests passed ✓',
                style: TextStyle(color: Colors.green, fontFamily: 'monospace'),
              ),
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                    child: const Text('Onayla & Devam', style: TextStyle(color: Colors.white)),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton(onPressed: () {}, child: const Text('Diff Görüntüle')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class DiffScreen extends StatelessWidget {
  const DiffScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('main.py - Diff')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Kod İncelemesi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                color: Colors.black87,
                child: const Text(
                  '- def old_function():\n+ def new_function():\n+     print("Updated code")\n+     return True\n-     return False',
                  style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 14),
                ),
              ),
              const SizedBox(height: 16),
              const Text('Yorumlar:', style: TextStyle(fontWeight: FontWeight.w600)),
              const TextField(decoration: InputDecoration(hintText: 'Yorum ekle...')),
              const SizedBox(height: 16),
              Row(
                children: [
                  ElevatedButton(onPressed: () {}, child: const Text('Kabul Et')),
                  const SizedBox(width: 8),
                  OutlinedButton(onPressed: () {}, child: const Text('Değişiklik İste')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
